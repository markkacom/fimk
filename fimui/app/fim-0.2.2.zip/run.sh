java -cp fim.jar:lib/*:conf nxt.Nxt
